package es.um.redes.nanoFiles.message;

public class PeerMessageOps {

	/*
	 * TODO: Añadir aquí todas las constantes que definen los diferentes tipos de
	 * mensajes del protocolo entre pares.
	 */
	public static final String OP_DOWNLOAD = "download";
	public static final String OP_DOWNLOAD_OK = "downloadok";
	public static final String OP_DOWNLOAD_FAIL = "downloadfail";
	public static final String OP_QUERYFILES = "queryfiles";
	public static final String OP_SERVEDFILES = "servedfiles";
}
